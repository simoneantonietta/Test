// PROTO
int set_tty_raw(void);
int set_tty_cbreak();
int set_tty_cooked();
unsigned char kb_getc(void);
unsigned int kb_getc_e(void);
unsigned char kb_getc_w(void);

