<div class="container">
	<h1>Login</h1>
    <div class="separator"></div>
</div>

<div id="login" class="container">
	<div class="row">

        <div class="col-lg-offset-3 col-lg-6">
        	<!-- form base di login -->
            <form action="" method="post">
                <div class="login_campo">
                    <div class="values"><input type="text" name="username" class="form-control" placeholder="Username" aria-describedby="codice-stampato" value="" ></div>
                </div>
                <div class="login_campo">
                    <div class="values"><input type="password" name="password" class="form-control" placeholder="Password" aria-describedby="password-badge" value="" ></div>
                </div>
                <div class="login_campo">
                    <button type="submit" name="login" class="btn btn-default btn-success pull-right">Login&nbsp;&nbsp;<span class="glyphicon glyphicon-lock" aria-hidden="true"></span></button>
                </div>
            </form>
        </div>

    </div>
</div>
