<?php
?>      

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Rilevamento terminali collegati</h4>
      </div>
      <div class="modal-body" style="text-align:center;">
	      <p>Attenzione la procedura potrebbe richiedere alcuni minuti...</p>
          <button class="btn btn-default btn-primary" onClick="getTerminals()">rileva terminali</button>
      </div>