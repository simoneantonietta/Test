<?php
	$editProfili = true;
?>

<div class="container">
	<h1>configurazione profili</h1>
    <div class="separator"></div>
</div>

<div id="configurazione-sistema" class="container">
	<div class="row">
        <div class="col-lg-offset-3 col-lg-6">
	      	<?php require('profili.php'); ?>
        </div>    
    </div>
</div>

<!-- Modal Profili -->
<div id="edit-profilo" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
    </div>
  </div>
</div>
