#!/bin/bash
# kill all varcosv processes

sudo pkill -e sv_startup.sh
pkill -e varcosv

