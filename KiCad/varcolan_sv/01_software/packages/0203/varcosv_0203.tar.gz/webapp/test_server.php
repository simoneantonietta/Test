<?php
var_dump(getenv('VARCO_RASP'));
?>