<div id="new-badge-modal">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Acquisizione badge</h4>
      </div>
      <div class="modal-body">
        <p style="text-align:center;"><img src="img/badge.gif" height="400" alt=""/></p>
      </div>
</div>