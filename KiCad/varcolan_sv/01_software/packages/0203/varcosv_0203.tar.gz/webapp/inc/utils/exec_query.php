<?php

include('../global.php');

$db = new SQLite3(DB_HOST);

$command = $_POST['query'];

$queries = explode(";", $command);

foreach($queries as $query) {
	$results = $db->query($query);
}

$myarray = $results->fetchArray();

$jsontext = json_encode($myarray);

echo($jsontext);

?>