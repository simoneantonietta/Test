#!/bin/bash
tail -f /tmp/varcosv.log

