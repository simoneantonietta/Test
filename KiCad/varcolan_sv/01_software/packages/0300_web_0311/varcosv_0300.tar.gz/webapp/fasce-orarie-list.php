<div class="container">
	<h1>configurazione fasce orarie</h1>
    <div class="separator"></div>
</div>

<div id="fasce-orarie" class="container">
	<div class="row">
        <div class="col-lg-offset-3 col-lg-6">
	      	<?php require('fasce-orarie.php'); ?>
        </div>    
    </div>
</div>

<!-- Modal Fasce orarie -->
<div id="edit-fascia-oraria" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
    <div class="modal-content">
    </div>
  </div>
</div>