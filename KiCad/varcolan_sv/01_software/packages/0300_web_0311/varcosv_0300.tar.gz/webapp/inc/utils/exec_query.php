<?php

class DB_Database extends SQLite3 {
  
    function db_query($query) {
        
    }
}

?>